# Diane Jen F. Arellano — Portfolio

A dark, tech-focused portfolio site built with plain HTML/CSS/JS. No build step, no dependencies — ready to deploy straight to Vercel.

## Files
- `index.html` — page structure and content
- `styles.css` — design tokens, layout, responsive rules
- `script.js` — nav behavior, typing effect, stat count-up, scroll reveal
- `vercel.json` — minor Vercel config (clean URLs)

## Before you deploy — edit these
1. **Email & links** — in `index.html`, search for:
   - `youremail@example.com` (appears twice, in the Contact section)
   - The `#` placeholders next to `GitHub`, `LinkedIn`, `Live website`, `View code` — replace with your real URLs.
2. **Resume link** — the "Resume ↗" button in the nav currently points to `#`. Either link it to a hosted PDF (e.g. `/resume.pdf` if you drop a file in this folder) or an external link.
3. **Project screenshot** — the featured project section currently shows a placeholder pattern instead of a real screenshot. Replace the `.browser-screen` div in `index.html` with an `<img>` tag once you have a screenshot of Xyve's Piloting Service, e.g.:
   ```html
   <div class="browser-screen">
     <img src="project-screenshot.png" alt="Xyve's Piloting Service homepage">
   </div>
   ```
   (Add matching CSS: `.browser-screen img { width:100%; height:100%; object-fit:cover; }`)

## Deploy to Vercel

**Option A — Vercel CLI**
```bash
npm i -g vercel
cd this-folder
vercel
```
Follow the prompts (link/create a project). Running `vercel` again after edits redeploys; `vercel --prod` pushes to your production URL.

**Option B — GitHub + Vercel dashboard**
1. Push this folder to a new GitHub repo.
2. Go to [vercel.com/new](https://vercel.com/new), import the repo.
3. Framework preset: **Other** (it's a static site — no build command needed).
4. Deploy.

## Customizing
- Colors, fonts, and spacing are all defined as CSS variables at the top of `styles.css` under `:root` — change the accent color there (`--accent`) to re-theme the whole site.
- Sections are ordered in `index.html` in the same order they appear on the page — reorder or remove `<section>` blocks freely.
