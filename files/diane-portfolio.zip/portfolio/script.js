// ---------- navbar scroll state ----------
const navbar = document.getElementById('navbar');
window.addEventListener('scroll', () => {
  navbar.classList.toggle('scrolled', window.scrollY > 20);
});

// ---------- mobile menu ----------
const navToggle = document.getElementById('navToggle');
const navLinksList = document.querySelector('.nav-links');
navToggle.addEventListener('click', () => {
  const open = navLinksList.style.display === 'flex';
  navLinksList.style.display = open ? 'none' : 'flex';
  navLinksList.style.flexDirection = 'column';
  navLinksList.style.position = 'fixed';
  navLinksList.style.top = '64px';
  navLinksList.style.left = '0';
  navLinksList.style.right = '0';
  navLinksList.style.background = '#0d0d0d';
  navLinksList.style.padding = '20px 32px';
  navLinksList.style.borderBottom = '1px solid #232323';
  navToggle.classList.toggle('active', !open);
});
document.querySelectorAll('.nav-links a').forEach(link => {
  link.addEventListener('click', () => {
    if (window.innerWidth <= 720) navLinksList.style.display = 'none';
  });
});

// ---------- typed code effect ----------
const codeLines = [
  "const developer = {",
  "  name: 'Diane Jen F. Arellano',",
  "  role: 'BSIT Student',",
  "  stack: ['HTML', 'CSS', 'JS'],",
  "  tools: ['Webflow', 'Vercel'],",
  "  mindset: 'learn by building',",
  "  status: 'open to opportunities'",
  "};"
];
const typedEl = document.getElementById('typedCode');
let lineIdx = 0, charIdx = 0;

function typeCode() {
  if (lineIdx >= codeLines.length) return;
  const line = codeLines[lineIdx];
  if (charIdx <= line.length) {
    const soFar = codeLines.slice(0, lineIdx).join('\n');
    typedEl.textContent = (soFar ? soFar + '\n' : '') + line.slice(0, charIdx);
    charIdx++;
    setTimeout(typeCode, 18 + Math.random() * 22);
  } else {
    lineIdx++;
    charIdx = 0;
    setTimeout(typeCode, 120);
  }
}
if (typedEl) setTimeout(typeCode, 500);

// ---------- stat count-up ----------
const statEls = document.querySelectorAll('.stat-num');
const statObserver = new IntersectionObserver((entries) => {
  entries.forEach(entry => {
    if (entry.isIntersecting) {
      const el = entry.target;
      const target = parseInt(el.getAttribute('data-count'), 10);
      let current = 0;
      const step = Math.max(1, Math.ceil(target / 30));
      const tick = () => {
        current += step;
        if (current >= target) { el.textContent = target; return; }
        el.textContent = current;
        requestAnimationFrame(tick);
      };
      tick();
      statObserver.unobserve(el);
    }
  });
}, { threshold: 0.6 });
statEls.forEach(el => statObserver.observe(el));

// ---------- scroll reveal ----------
const revealTargets = document.querySelectorAll(
  '.section-head, .what-card, .stack-group, .featured-grid, .project-row, .timeline-item, .approach-step, .goal-text, .contact-inner, .about-body, .about-grid > .section-head'
);
revealTargets.forEach(el => el.classList.add('fade-up'));

const revealObserver = new IntersectionObserver((entries) => {
  entries.forEach(entry => {
    if (entry.isIntersecting) {
      entry.target.classList.add('in-view');
      revealObserver.unobserve(entry.target);
    }
  });
}, { threshold: 0.15 });
revealTargets.forEach(el => revealObserver.observe(el));
